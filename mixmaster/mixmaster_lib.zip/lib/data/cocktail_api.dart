import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;

import 'models.dart';

/// Cliente da TheCocktailDB (chave de testes "1").
/// Docs: https://www.thecocktaildb.com/documentation
class CocktailApi {
  static const _host = 'www.thecocktaildb.com';
  static const _base = '/api/json/v1/1';
  static final http.Client _client = http.Client();
  static final Random _rng = Random();

  static List<String>? _ingredientNames;
  static final Map<String, Future<Ingredient?>> _ingredientCache = {};

  static Future<Map<String, dynamic>?> _get(
    String endpoint,
    Map<String, String> query,
  ) async {
    final uri = Uri.https(_host, '$_base/$endpoint', query);
    final res = await _client.get(uri);
    if (res.statusCode != 200) {
      throw Exception('Erro ${res.statusCode} ao acessar a API');
    }
    final body = utf8.decode(res.bodyBytes).trim();
    if (body.isEmpty) return null;
    final data = json.decode(body);
    return data is Map<String, dynamic> ? data : null;
  }

  static List<Drink> _drinks(Map<String, dynamic>? data) {
    final list = data?['drinks'];
    if (list is! List) return const [];
    return list
        .whereType<Map<String, dynamic>>()
        .map(Drink.fromJson)
        .toList();
  }

  // ---------------------------------------------------------------- Drinks

  static Future<Drink?> randomDrink() async {
    final list = _drinks(await _get('random.php', {}));
    return list.isEmpty ? null : list.first;
  }

  /// A versão gratuita só devolve 1 drink por chamada; fazemos várias em
  /// paralelo e removemos repetidos.
  static Future<List<Drink>> randomDrinks(int count, {Set<String>? exclude}) async {
    final results = await Future.wait(
      List.generate(count + 4, (_) => randomDrink().catchError((_) => null)),
    );
    final seen = <String>{...?exclude};
    final out = <Drink>[];
    for (final d in results) {
      if (d != null && seen.add(d.id)) out.add(d);
      if (out.length == count) break;
    }
    if (out.isEmpty) throw Exception('Sem resposta da API');
    return out;
  }

  static Future<List<Drink>> searchByName(String name) async =>
      _drinks(await _get('search.php', {'s': name}));

  static Future<Drink?> lookup(String id) async {
    final list = _drinks(await _get('lookup.php', {'i': id}));
    return list.isEmpty ? null : list.first;
  }

  static Future<List<Drink>> filterByIngredient(String ingredient) async =>
      _drinks(await _get('filter.php', {'i': ingredient}));

  /// A API gratuita só filtra por UM ingrediente por vez, então buscamos cada
  /// um e fazemos a interseção (drinks que levam TODOS os ingredientes).
  static Future<List<Drink>> filterByIngredients(List<String> names) async {
    if (names.isEmpty) return const [];
    final lists = await Future.wait(names.map(filterByIngredient));
    var ids = lists.first.map((d) => d.id).toSet();
    for (final l in lists.skip(1)) {
      ids = ids.intersection(l.map((d) => d.id).toSet());
    }
    return lists.first.where((d) => ids.contains(d.id)).toList();
  }

  /// Sorteio por humor: junta os resultados dos filtros do humor, escolhe um
  /// drink aleatório e busca os detalhes completos.
  static Future<Drink?> drinkForMood(Mood mood) async {
    if (mood.filters.isEmpty) return randomDrink();
    final lists = await Future.wait(
      mood.filters.map((f) async =>
          _drinks(await _get('filter.php', {f.key: f.value}))),
    );
    final all = lists.expand((l) => l).toList();
    if (all.isEmpty) return randomDrink();
    final pick = all[_rng.nextInt(all.length)];
    return lookup(pick.id);
  }

  // ----------------------------------------------------------- Ingredientes

  static Future<List<String>> ingredientNames() async {
    if (_ingredientNames != null) return _ingredientNames!;
    final data = await _get('list.php', {'i': 'list'});
    final list = data?['drinks'];
    if (list is! List) throw Exception('Não foi possível listar ingredientes');
    final names = list
        .whereType<Map<String, dynamic>>()
        .map((e) => (e['strIngredient1'] ?? '') as String)
        .where((n) => n.isNotEmpty)
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return _ingredientNames = names;
  }

  static Future<Ingredient?> ingredientDetails(String name) {
    return _ingredientCache.putIfAbsent(name, () async {
      try {
        final data = await _get('search.php', {'i': name});
        final list = data?['ingredients'];
        if (list is! List || list.isEmpty) return null;
        return Ingredient.fromJson(list.first as Map<String, dynamic>);
      } catch (_) {
        _ingredientCache.remove(name);
        return null;
      }
    });
  }

  /// Imagem do ingrediente (size: Small 100px, Medium 350px, '' 700px).
  static String ingredientImage(String name, {String size = 'Small'}) {
    final suffix = size.isEmpty ? '' : '-$size';
    return 'https://$_host/images/ingredients/${Uri.encodeComponent(name)}$suffix.png';
  }
}
